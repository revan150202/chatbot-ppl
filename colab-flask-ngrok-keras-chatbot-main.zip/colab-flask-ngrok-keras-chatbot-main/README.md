# colab-flask-ngrok-keras-chatbot
This is a chatbot that should work with one click on a google colab account.


The idea is simple: anyone should be able to get a simple chatbot working with very little effort. I believe I have done that.
https://colab.research.google.com/drive/1zooAiTUH_Fs19vdlfYWsL6xTW8pAPAfA?usp=sharing
